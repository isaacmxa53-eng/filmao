const DATA = [
  {
    id: '1',
    nome: "Tubarão (Jaws)",
    imagem: require('../img-filmes/jaws.jpg'),
    imdb: '8.1',
    sinopse: "Um enorme tubarão-branco começa a aterrorizar uma cidade litorânea. Um chefe de polícia, um oceanógrafo e um caçador partem em uma perigosa missão para impedir novos ataques."
  },
  {
    id: '2',
    nome: "Jurassic Park",
    imagem: require('../img-filmes/jurassic-park.jpg'),
    imdb: '8.2',
    sinopse: "Um parque temático construído em uma ilha reúne dinossauros recriados por engenharia genética. Quando o sistema de segurança falha, os visitantes precisam lutar para sobreviver."
  },
  {
    id: '3',
    nome: "Guardiões da Galáxia Vol. 2",
    imagem: require('../img-filmes/guardioes-galaxia-vol2.jpg'),
    imdb: '7.6',
    sinopse: "Os Guardiões da Galáxia embarcam em novas aventuras pelo universo enquanto Peter Quill descobre segredos sobre sua origem. A equipe precisa permanecer unida diante de ameaças inesperadas."
  },
  {
    id: '4',
    nome: "O Senhor dos Anéis: A Sociedade do Anel",
    imagem: require('../img-filmes/senhor-dos-aneis-sociedade-anel.jpg'),
    imdb: '8.8',
    sinopse: "Frodo recebe a missão de destruir um anel capaz de ameaçar toda a Terra-média. Ao lado de companheiros de diferentes povos, ele parte em uma jornada perigosa até Mordor."
  }
];

export default DATA;
