import {Text, View, Image} from 'react-native';
import styles from './style'

export default function Banner() {
    return (
        <View style={styles.input}>

            <Text style={styles.mainText}> Em cartaz </Text>
                  <Image
                    style={styles.imagem}
                    source={require('../../../img-filmes/jurassic-park.jpg')}/>
                   <Text style={styles.titleName}> Jurassic Park: Parque dos Dinossauros </Text>
        </View>

    );
}